﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirlineSystem
{
    class FlightsDataBL
    {
        public string FlightName;
        public string FlightTime;
        public string FlightRoute;
        public double FlightPrice;
        public int FlightTickets;

        public FlightsDataBL(string name, string time, string route, double price, int tickets)
        {
            FlightName = name;
            FlightTime = time;
            FlightRoute = route;
            FlightTickets = tickets;
            FlightPrice = price;
        }
    }
}
